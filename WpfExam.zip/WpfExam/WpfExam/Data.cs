﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfExam
{
    class Data
    {
        public int Key { set; get; }
        public char Value { set; get; }

        //Compare objects by Value
        public static bool Compare(Data x, Data y)
        {
            return (x.Value == y.Value);         
        }
    }
}
