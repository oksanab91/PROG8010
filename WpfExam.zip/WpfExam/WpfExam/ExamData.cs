﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WpfExam
{
    class ExamData: INotifyPropertyChanged       
    {
        //Constants
        const string DATA_FILE = "exam_data/ex_data.txt";
        const int EXAM_PASS_LEVEL = 15;
        const string ANSWERS = "1.B 2.D 3.A 4.A 5.C 6.A 7.B 8.A 9.C 10.D 11.B 12.C 13.D 14.A 15.D 16.C 17.C 18.B 19.D 20.A";

        //Private vars
        private Data[] arrAnswers;
        private Data[] arrStudAnswers;
        private List<Data> lsIncorrect;
        private int correctCount = 0;
        private int incorrectCount = 0;
        
        #region OnPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;      
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChangedEventHandler eventHandler = this.PropertyChanged;
            if (eventHandler != null)
            {
                eventHandler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        //Public properties
        public List<Data> ListIncorrectAns
        {
            set { lsIncorrect = value; OnPropertyChanged(""); } get { return lsIncorrect;} 
        }
        public int CorrectAnsCount
        {
            set { correctCount = value; OnPropertyChanged(""); } get { return correctCount; }
        }        
        public int IncorrectAnsCount
        {
            set { incorrectCount = value; OnPropertyChanged(""); } get { return incorrectCount; }
        }

        #region PrivateMethods
        //Splits string and creates array
        private Data[] SplitToArray(string sourseStr)
        {
            Data[] returnVal;
            const char SPLIT_CHAR = '.';

            string[] splitData = sourseStr.Split(new char[] { ' ', '\r', '\n' });
            Data[] buildData = new Data[] { };
          
            for(int indX=0; indX<splitData.Length; indX++)            
            {
                string sd = splitData[indX];
                Data dt = new Data();
                string[] item = sd.Split(SPLIT_CHAR);

                dt.Key = int.Parse(item[0].Trim());                
                dt.Value = item[1].Trim()[0];
                
                Array.Resize(ref buildData, indX + 1);
                buildData.SetValue(dt, indX);
            }

            //Sort array
            returnVal = buildData.OrderBy(i => i.Key).ToArray();

            //----------------------------------------
            return returnVal;
        }

        //Reads file with student's answers
        private void ReadAnswerData()
        {
            string fileData = File.ReadAllText(DATA_FILE);
            arrStudAnswers=SplitToArray(fileData);            
        }

        //Reads file with valid answers
        private void FillArrAnswers()
        {
            arrAnswers = SplitToArray(ANSWERS);
        }

        //Checks exam result
        private bool EvaluateAnswers()
        {
            ListIncorrectAns = new List<Data>();
        
            for (int indArr = 0; indArr < arrStudAnswers.Length; indArr++)
            {
                Data studentAns = arrStudAnswers[indArr];
                Data setAns = arrAnswers[indArr];

                if (!Data.Compare(studentAns, setAns))              
                {
                    ListIncorrectAns.Add(studentAns);
                    IncorrectAnsCount++;
                }
            }

            CorrectAnsCount = arrAnswers.Length - IncorrectAnsCount;

            //----------------------------------------
            return (CorrectAnsCount >= EXAM_PASS_LEVEL);
        }
        #endregion

        //Validates exma data and returns result
        public bool CheckExamData()
        {
            bool returnVal = false;

            FillArrAnswers();
            ReadAnswerData();
            returnVal = EvaluateAnswers();

            //-----------------------
            return returnVal;
        }

        //Constructor
        public ExamData()
        {
            ListIncorrectAns = new List<Data>();
        }
    }
}
