﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WpfSalesPackagesApp
{
    class CalcPackeges : INotifyPropertyChanged
    {
        const decimal BASE_PRICE_VAL = 99m;    //retail package price
        const decimal DISCOUNT_20_VAL = 0.2m;  //20%
        const decimal DISCOUNT_30_VAL = 0.3m;  //30%
        const decimal DISCOUNT_40_VAL = 0.4m;  //40%
        const decimal DISCOUNT_50_VAL = 0.5m;  //50%

        const int DISCOUNT_20_QUANT_LOWER = 10;
        //const int DISCOUNT_20_QUANT_UPPER = 19;

        const int DISCOUNT_30_QUANT_LOWER = 20;
        //const int DISCOUNT_30_QUANT_UPPER = 49;

        const int DISCOUNT_40_QUANT_LOWER = 50;
        //const int DISCOUNT_40_QUANT_UPPER = 99;

        const int DISCOUNT_100_QUANT_LOWER = 100;       



        //private decimal basePriceVal = 0;
        private decimal discountAmountVal = 0;
        private int packagesQuantityVal = 0;
        private decimal totalPriceVal = 0;

        #region Properties
        //public decimal BasePrice
        //{
        //    get { return basePriceVal; }
        //    set { basePriceVal = value; }
        //}
        public decimal DiscountAmount
        {
            get { return discountAmountVal; }
            set { discountAmountVal = value; OnPropertyChanged(); }
        }
        public decimal TotalPrice
        {
            get { return totalPriceVal; }
            set { totalPriceVal = value; OnPropertyChanged(); }
        }

        public int PackagesQuantity
        {
            get { return packagesQuantityVal; }
            set { packagesQuantityVal = value; OnPropertyChanged(); }
        }
        #endregion

        #region PropertyChange
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));                
            }
        }
        #endregion

        #region Calculation
        public void CalcRun()
        {
            try
            {
                totalPriceVal = BASE_PRICE_VAL;
                decimal discountPercVal = 0;             

                if (packagesQuantityVal >= DISCOUNT_100_QUANT_LOWER)
                {
                    discountPercVal = DISCOUNT_50_VAL;
                }
                else if (packagesQuantityVal >= DISCOUNT_40_QUANT_LOWER)
                {
                    discountPercVal = DISCOUNT_40_VAL;
                }
                else if (packagesQuantityVal >= DISCOUNT_30_QUANT_LOWER)
                {
                    discountPercVal = DISCOUNT_30_VAL;
                }
                else if (packagesQuantityVal >= DISCOUNT_20_QUANT_LOWER)
                {
                    discountPercVal = DISCOUNT_20_VAL;
                }
                

                //----------------------------------------
                if (discountPercVal>0)
                {
                    //discount amount
                    DiscountAmount = BASE_PRICE_VAL * discountPercVal;
                    //total amount
                    TotalPrice -= discountAmountVal;
                }
                //----------------------------------------

                //return PackagesQuantity > 0;
            }
            catch { }
                       
        }
        #endregion
        //public method to clear data
        public void Clear()
        {            
            DiscountAmount = 0;            
            TotalPrice = 0;            
        }

    }
}
