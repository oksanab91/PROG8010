﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfPopulation
{
    class PopulationData
    {
        const string PLEASE_ENTER = "Please Enter";
        const string VALID_DATA = "Valid Data";

        string dayVal = string.Empty;
        string sizeVal = string.Empty;

        public string Day
        { 
            get { return dayVal; }
            set { dayVal = value; }
        }        
        public string Size
        {
            get { return sizeVal; }
            set { sizeVal = value; }
        }

        //Constructor with default values
        public PopulationData()
        {
            dayVal = PLEASE_ENTER;
            sizeVal = VALID_DATA;
        }

        public override string ToString()
        {           
            return Day + " : " + Size;
        }          
    }    
}
