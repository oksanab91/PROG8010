﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfPopulation
{
    class PopulationVM: INotifyPropertyChanged
    {
        const string DIR_NAME = "PopulationData";
        const string FILE_NAME= "simulation.txt";

        //Starting number of organisms
        long startNumberVal = 0;
        public long StartNumber
        {
            get { return startNumberVal; }
            set
            {
                startNumberVal = value;                
                DoCalcPopulation();
                Notify("StartNumber");
            }
        }

        //The average daily population increase %
        int increasePctVal = 0;
        public int IncreasePct
        {
            get { return increasePctVal; }
            set
            {
                increasePctVal = value;                
                DoCalcPopulation();
                Notify("IncreasePct");
            }
        }

        //The number of days organisms will be multiply
        int daysNumberVal = 0;
        public int DaysNumber
        {
            get { return daysNumberVal; }
            set
            {
                daysNumberVal = value;                
                DoCalcPopulation();
                Notify("DaysNumber");
            }
        }

        //The population size for each day
        List<PopulationData> resultListVal;
        public List<PopulationData> ResultList
        {
            get
            {
                return resultListVal;                
            }
            set
            {
                resultListVal = value;
                Notify("ResultList");
            }         
        }

        #region Functions

        //predicts the approximate size of a population of organisms
        private bool DoCalcPopulation()
        {
            bool returnVal = false;
            int dayVal = 1;
            double populationVal = startNumberVal;
            
            ResultList = null;
            ResultList = new List<PopulationData>();

            //Calculates per day and fills the list
            if (populationVal > 0 && increasePctVal > 0 && daysNumberVal>0)
            {
                while (dayVal <= daysNumberVal)
                {
                    populationVal *= 1 + (double)increasePctVal / 100;

                    //New data object               
                    PopulationData data = new PopulationData();
                    data.Day = dayVal.ToString();
                    data.Size = Math.Round(populationVal).ToString();

                    //Add data object to the list
                    ResultList.Add(data);

                    dayVal++;
                }
                returnVal = true;
            }
            else
            {
                PopulationData data = new PopulationData(); 
            }           
            return returnVal;
        }

        //Saves the current prediction to a file
        public bool Save()
        {
            bool RetValue = true;

            try
            {
                string path = System.Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                string fullpath = Path.Combine(path, DIR_NAME);
                Directory.CreateDirectory(fullpath);
                string fullname = Path.Combine(fullpath, FILE_NAME);

                StreamWriter sw = File.AppendText(fullname);

                foreach (PopulationData d in ResultList)
                {
                    sw.WriteLine(d.ToString());
                }

                sw.Close();                
            }
            catch { RetValue = false; }
                       
            return RetValue;
        }

        #endregion
 
        //Constructor
        public PopulationVM()
        {
            resultListVal = new List<PopulationData>();
            PopulationData data = new PopulationData();
            //Add default data object to the list
            ResultList.Add(data);
        }

        #region PropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;
        protected void Notify(string caller = null)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(caller));
        }

        #endregion
    }    
}
