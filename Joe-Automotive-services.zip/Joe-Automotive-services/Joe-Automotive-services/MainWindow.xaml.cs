﻿using System.Windows;

namespace Joe_Automotive_services
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Josservice josobj;
        public MainWindow()
        {
            InitializeComponent();
            josobj = new Josservice();
            DataContext = josobj;
        }

        //Calculates the charges
        private void btncalculate_Click(object sender, RoutedEventArgs e)
        {
            josobj.Calculate();            
        }

        //Clears all the controls
        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            josobj.ClearData();
        }
    }
}
