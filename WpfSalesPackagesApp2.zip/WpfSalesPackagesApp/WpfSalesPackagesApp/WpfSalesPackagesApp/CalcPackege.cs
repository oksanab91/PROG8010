﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WpfSalesPackagesApp
{
    //class to calculate amounts, used in bounding   
    class CalcPackeges : INotifyPropertyChanged
    {
        //constants
        public const decimal BASE_PRICE_VAL = 99m;  //retail package price
        const decimal DISCOUNT_20_VAL = 0.2m;       //20%
        const decimal DISCOUNT_30_VAL = 0.3m;       //30%
        const decimal DISCOUNT_40_VAL = 0.4m;       //40%
        const decimal DISCOUNT_50_VAL = 0.5m;       //50%
        
        const int DISCOUNT_20_QUANT_LOWER = 10; 
        const int DISCOUNT_30_QUANT_LOWER = 20;
        const int DISCOUNT_40_QUANT_LOWER = 50; 
        const int DISCOUNT_100_QUANT_LOWER = 100;       
        
       //vars
        private decimal discountAmountVal = 0;
        private uint packagesQuantityVal = 0;
        private decimal totalPriceVal = 0;
        private decimal discountPercVal = 0;

        #region Properties
              
            public Decimal DiscountPerc
        {
            get { return discountPercVal; }
            set { discountPercVal = value; OnPropertyChanged(); }
        }       
        public decimal DiscountAmount
        {
            get { return discountAmountVal; }
            set { discountAmountVal = value; OnPropertyChanged(); }
        }
        public decimal TotalPrice
        {
            get { return totalPriceVal; }
            set { totalPriceVal = value; OnPropertyChanged(); }
        }

        public uint PackagesQuantity
        {
            get { return packagesQuantityVal; }
            set { packagesQuantityVal = value; OnPropertyChanged(); }
        }
        #endregion

        #region PropertyChange
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));                
            }
        }
        #endregion
        
        //function to run calculation and to fill the vars        
        public void CalcRun()
        {
            try
            {
                TotalPrice = BASE_PRICE_VAL * packagesQuantityVal;
                
                //sets discount percentage by the quantity          
                //50%
                if (packagesQuantityVal >= DISCOUNT_100_QUANT_LOWER)
                {
                    discountPercVal = DISCOUNT_50_VAL;
                }
                //40%
                else if (packagesQuantityVal >= DISCOUNT_40_QUANT_LOWER)
                {  
                    discountPercVal = DISCOUNT_40_VAL;
                }
                //30%
                else if (packagesQuantityVal >= DISCOUNT_30_QUANT_LOWER)
                {
                    discountPercVal = DISCOUNT_30_VAL;
                }
                //20%
                else if (packagesQuantityVal >= DISCOUNT_20_QUANT_LOWER)
                {
                    discountPercVal = DISCOUNT_20_VAL;
                }
                

                //---------------------------------------------
                //if there is a discount then calculate amounts
                if (discountPercVal>0)
                {
                    //discount amount
                    DiscountAmount = totalPriceVal * discountPercVal;
                    //total amount
                    TotalPrice -= discountAmountVal;
                }
                //---------------------------------------------

            }
            catch { }                       
        }       

        //public method to clear class data
        public void Clear()
        {            
            DiscountAmount = 0;            
            TotalPrice = 0;
            DiscountPerc = 0;            
        }

    }
}
