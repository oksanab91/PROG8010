﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WorkshopCalc
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
   
        WorkshopCalc.WorkshopSelector workshopSelected;

        public MainWindow()
        {
            InitializeComponent();

            workshopSelected = new WorkshopCalc.WorkshopSelector();
            DataContext = workshopSelected;
            //workshopSelected.TotalStr
        }

        private void btnCalc_Click(object sender, RoutedEventArgs e)
        {
            if (workshopSelected.RunCalculation()) { }
            //tblPrice.Text = "Cost of selected workshop: $" + workshopSelected.TotalStr;           
            else
                MessageBox.Show("Please select a city and a workshop");
        }
      
    //private void lbWorkshop_SelectionChanged(object sender, SelectionChangedEventArgs e)
    //{
        //if (lbWorkshop.SelectedIndex.Equals(0))
        //{
        //    days = HANDLING_STRESS_DAYS;
        //    fee = HANDLING_STRESS_FEE;
        //}
        //if (lbWorkshop.SelectedIndex.Equals(1))
        //{
        //    days = TIME_MANAGEMENT_DAYS;
        //    fee = TIME_MANAGEMENT_FEE;
        //}
        //if (lbWorkshop.SelectedIndex.Equals(2))
        //{
        //    days = SUPERVISION_DAYS;
        //    fee = SUPERVISION_FEE;
        //}
        //if (lbWorkshop.SelectedIndex.Equals(3))
        //{
        //    days = NEGOTIATION_DAYS;
        //    fee = NEGOTIATION_FEE;
        //}
        //if (lbWorkshop.SelectedIndex.Equals(4))
        //{
        //    days = INTERVIEW_DAYS;
        //    fee = INTERVIEW_FEE;
        //}

    }

//private void lbLocation_SelectionChanged(object sender, SelectionChangedEventArgs e)
//{
            //if (lbLocation.SelectedIndex.Equals(0))
            //{
            //    lodging = AUSTIN_LODGE;
            //}
            //if (lbLocation.SelectedIndex.Equals(1))
            //{
            //    lodging = CHICAGO_LODGE;
            //}
            //if (lbLocation.SelectedIndex.Equals(2))
            //{
            //    lodging = DALLAS_LODGE;
            //}
            //if (lbLocation.SelectedIndex.Equals(3))
            //{
            //    lodging = ORLANDO_LODGE;
            //}
            //if (lbLocation.SelectedIndex.Equals(4))
            //{
            //    lodging = PHOENIX_LODGE;
            //}
            //if (lbLocation.SelectedIndex.Equals(5))
            //{
            //    lodging = RALEIGH_LODGE;
    //    }
    //}
}

