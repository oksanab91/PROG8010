﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace WorkshopCalc
{
    class ListSelector : INotifyPropertyChanged
    {
        private List<string> currentList;
        private string currentListItem;

        #region Properties

        public List<string> CurrentList
        {
            get { return currentList; }
            set { currentList = value; OnPropertyChanged(); }
        }

        public string CurrentListItem
        {
            get { return currentListItem; }
            set { currentListItem = value; OnPropertyChanged(); }
        }

        #endregion

        #region constructor
        public ListSelector(List<String> newList)
        {
            currentList = new List<string>();
            currentList.AddRange(newList);
        }
        #endregion

        #region PropertyChange

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name=null)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        #endregion
    
    }

    class WorkshopSelector
    {
        const int HANDLING_STRESS_DAYS = 3;
        const int TIME_MANAGEMENT_DAYS = 3;
        const int SUPERVISION_DAYS = 3;
        const int NEGOTIATION_DAYS = 5;
        const int INTERVIEW_DAYS = 1;
        const decimal HANDLING_STRESS_FEE = 1000m;
        const decimal TIME_MANAGEMENT_FEE = 800m;
        const decimal SUPERVISION_FEE = 1500m;
        const decimal NEGOTIATION_FEE = 1300m;
        const decimal INTERVIEW_FEE = 500m;
        const decimal AUSTIN_LODGE = 150m;
        const decimal CHICAGO_LODGE = 225m;
        const decimal DALLAS_LODGE = 175m;
        const decimal ORLANDO_LODGE = 300m;
        const decimal PHOENIX_LODGE = 175m;
        const decimal RALEIGH_LODGE = 150m;

        const string TOTAL_PREFIX = "Cost of selected workshop: $";

        private int days=0;
        private decimal fee=0;
        private decimal lodging=0;
        private string totalStrVal = "";
        private ListSelector locationsList;
        private ListSelector workshopList;

        #region Properties
        public string TotalStr
        {
            //creates total sum string  
            get { return totalStrVal; }
            set
            {
                totalStrVal = value; 
                Notify();
            }
        }
        public ListSelector LocationList
        {
            get { return locationsList; }            
        }
        public ListSelector WorkshopList
        {
            get { return workshopList; }
        }
        #endregion

        #region PropertyChange
        public event PropertyChangedEventHandler SelectorNotify;
        protected virtual void Notify([CallerMemberName] string propertyName = null)
        {
            if (SelectorNotify != null)
            {
                SelectorNotify(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        //public event PropertyChangedEventHandler PropertyChanged;
        //protected void OnPropertyChanged(string name=null)
        //{
        //    PropertyChangedEventHandler handler = PropertyChanged;
        //    if (handler != null)
        //    {
        //        handler(this, new PropertyChangedEventArgs(name));
        //    }
        //}

        #region constructor
        public WorkshopSelector()
        {
            InitLists();
        }
        #endregion

        //-------------------------------------------------------
        //fills the lists
        //-------------------------------------------------------
        public void InitLists()
        {
            List<string> listData = new List<string>();
            listData.Add("Austin");
            listData.Add("Chicago");
            listData.Add("Dallas");
            listData.Add("Orlando");
            listData.Add("Phoenix");
            listData.Add("Raleigh");

            locationsList = new ListSelector(listData);
            listData.Clear();

            listData.Add("Handling Stress");
            listData.Add("Time Management");
            listData.Add("Supervision Skills");
            listData.Add("Negotiation");
            listData.Add("How to Interview");

            workshopList = new ListSelector(listData);
            listData.Clear();
        }

        //-------------------------------------------------------
        //sets value by selected workshops list item
        //-------------------------------------------------------
        public void SelectListWorkshop()
        {   
            switch (workshopList.CurrentListItem)
            {
                case "Handling Stress":
                    days = HANDLING_STRESS_DAYS;
                    fee = HANDLING_STRESS_FEE;
                    break;
                case "Time Management":
                    days = TIME_MANAGEMENT_DAYS;
                    fee = TIME_MANAGEMENT_FEE;
                    break;
                case "Supervision Skills":
                    days = SUPERVISION_DAYS;
                    fee = SUPERVISION_FEE;
                    break;
                case "Negotiation":
                    days = NEGOTIATION_DAYS;
                    fee = NEGOTIATION_FEE;
                    break;
                case "How to Interview":
                    days = INTERVIEW_DAYS;
                    fee = INTERVIEW_FEE;
                    break;            
            }   
        }

        //-------------------------------------------------------
        //sets value by selected locations list item
        //-------------------------------------------------------
        public void SelectListLocation()
        {
            switch (locationsList.CurrentListItem)
            {  
                case "Austin":
                    {
                        lodging = AUSTIN_LODGE;
                        break;
                    }
                case "Chicago":
                    {
                        lodging = CHICAGO_LODGE;
                        break;
                    }
                case "Dallas":
                    {
                        lodging = DALLAS_LODGE;
                        break;
                    }
                case "Orlando":
                    {
                        lodging = ORLANDO_LODGE;
                        break;
                    }
                case "Phoenix":
                    {
                        lodging = PHOENIX_LODGE;
                        break;
                    }
                case "Raleigh":
                    {
                        lodging = RALEIGH_LODGE;
                        break;
                    }
            }
        }

        //-------------------------------------------------------
        //calculates total sum by items selected in both lists
        //returns false in case of invalid input
        //-------------------------------------------------------
        public bool RunCalculation()
        {
            bool returnVal = true;
            totalStrVal = string.Empty;

            //sets value by selected workshops list item
            SelectListWorkshop();

            //sets value by selected locations list item
            SelectListLocation();

            //invalid input
            if (workshopList.CurrentListItem == null || locationsList.CurrentListItem == null)
            {
                returnVal = false;
            }
            //total sum
            else
            {       
                TotalStr = ((lodging * days) + fee).ToString("N2");
            }

            return returnVal;       
        }   
    }
}

  

