﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

// Vu Nguyen
// Oksana Blagutin
// Harsh Ahluwalia
// Arun Prabu
// Yasir Altahir
//Jon Plumbtree

namespace WpfImpotantInformation
{
    class FamilyInformation : INotifyPropertyChanged
    {
        //Constants for the text to display
        private const String MY_INFO= "My";
        private const String FATHER_INFO= "Father";
        private const String MOTHER_INFRO = "Mother";

#region public properties
        // My list
        public List<Data> MyInfo
        {
            get { return _myInfo; }
            set { _myInfo = value; OnPropertyChanged(); }
        }
        private List<Data> _myInfo;

        // Father list
        public List<Data> FatherInfo
        {
            get { return _fatherInfo; }
            set { _fatherInfo = value; OnPropertyChanged(); }
        }
        private List<Data> _fatherInfo;
       
        // Mother list
        public List<Data> MotherInfo
        {
            get { return _motherInfo; }
            set { _motherInfo = value; OnPropertyChanged(); }
        }
        private List<Data> _motherInfo;
#endregion

#region public methods
        // Adding the Information to the Lists

        // My information
        public void FillMyInformation()
        {           
            Data obj = new Data("Vu", "73 Doon St N Kitchener",56, "519 888 7777", MY_INFO);
            _myInfo.Add(obj);
        }

        // Father information
        public void FillFatherInformation()
        {            
            Data obj = new Data("Suzuki", "133 Blockline Rd S Toronto", 120, "00249 123 4567", FATHER_INFO);
            _fatherInfo.Add(obj);
        }

        // Mother information
        public void FillMotherInformation()
        {                   
            Data obj = new Data("Sara", "133 blockline Rd S Toronto", 57, "00249 123 4567", MOTHER_INFRO);   
            _motherInfo.Add(obj);
        }
#endregion

        //Constructor
        public FamilyInformation()
        {
            _myInfo = new List<Data>();
            _fatherInfo = new List<Data>();
            _motherInfo = new List<Data>();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChangedEventHandler eventHandler = this.PropertyChanged;
            if (eventHandler != null)
            {
                eventHandler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
