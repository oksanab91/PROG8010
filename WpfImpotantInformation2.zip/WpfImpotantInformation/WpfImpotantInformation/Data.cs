﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfImpotantInformation
{
    class Data
    {   
        //Public properties
        public string Name { get; set; }
        public  string Address { get; set; }
        public  int Age { get; set; }
        public string PhoneNum { get; set; }
        public string InfoPrefix { get; set; }
        
        //Public method        
        public override string ToString()
        {                
            return InfoPrefix + " Name: " + Name +"\n "+ "Address: " + Address + "\n " + "Age: " + Age.ToString() + "\n " + "Phone Number: " + PhoneNum;
        }

        //Constructor with parameters to fill the object
        public Data(string name, string address, int age, string phoneNum, string prefix)
        {
            InfoPrefix = prefix;
            Name = name;
            Address = address;
            Age = age;
            PhoneNum = phoneNum;
        }
    }
}
