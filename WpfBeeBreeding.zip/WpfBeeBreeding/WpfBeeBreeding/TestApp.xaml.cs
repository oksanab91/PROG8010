﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfBeeBreeding
{
    /// <summary>
    /// Interaction logic for TestApp.xaml
    /// </summary>
    public partial class TestApp : Window
    {
        public TestApp()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DistancePreview dv = new DistancePreview();
            dv.CreateFile();            
        }    
    }
}
