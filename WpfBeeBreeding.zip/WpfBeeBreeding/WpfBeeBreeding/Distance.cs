﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WpfBeeBreeding
{
    public enum EAx
    {
        AX_NONE,
        AX_X,
        AX_Y,
        AX_Z        
    }
    class Distance
    {
        //used for calculations
        const double BASE_SIX = 6;

        //row of a number
        private RowData Row { get; set; } 

        private int distance;
        public int FoundDistance
        {
            get { return distance; }
            set { distance = value; }
        }
        //a number of the pare
        private int startNumber;
        public int StartNumber
        {
            get { return startNumber; }
            set { startNumber = value; }
        }
        //a number of the pare
        private int endNumber;
        public int EndNumber
        {
            get { return endNumber; }
            set { endNumber = value; }
        } 
        public override string ToString()
        {
            return "The distance between cells " + StartNumber + " and " + EndNumber + " is " + FoundDistance;
        }

        //gets coordinates of the cells and calculates the distance
        public void GetDistance()
        {
            CellData cdStart = GetCoordinates(StartNumber);
            CellData cdEnd = GetCoordinates(EndNumber);
            FoundDistance = FindDistance(cdStart, cdEnd);
        }

        #region distance calculation private methods
        //returns distance between the cells
        private int FindDistance(CellData startCell, CellData endCell)
        {
            return (Math.Abs(startCell.X - endCell.X) + Math.Abs(startCell.Y - endCell.Y) + Math.Abs(startCell.Z - endCell.Z)) / 2;
        }

        //uses arithmetic progression to find a row number 
        private int FindRadius(int findNumber)
        {
            //step
            const int D_STEP = 1;            
            
            //sum of the numbers: 1,2,3,4... /row numbers/
            double sumN = Math.Ceiling((findNumber-1) / BASE_SIX);
            
            //first a /=1/
            int a1 = 1;
            //to find n = row
            int n = -1;

            if (findNumber <= 1)
                n = 0;
            else if (sumN == 1)
                n = 1;
            /*==================================
            sumN = ((2 * a1 + (n - 1)) * D_STEP) * n / 2;            
            ((2 * a1 + (n - 1)) * D_STEP) * n = sumN * 2
            2 * a1 * D_STEP * n + (n - 1) * D_STEP * n = sumN * 2
            n * (2 * a1 * D_STEP + (n - 1) * D_STEP) = sumN * 2
            D_STEP * (2 * a1 * n + (n - 1) * n) = sumN * 2
            (2 * a1 * n + (n - 1) * n) = sumN * 2 / D_STEP
            (2 * a1 * n + n^2 - n) = sumN * 2 / D_STEP          

            n^2 + a1 * n - (sumN * 2 / D_STEP) = 0
            ------------------------------------
            quadratic formula: //x = -b (+-) sqrt (b ^ 2 -4ac ) / 2a
            ax ^2 + bx + c = 0 
            D=b^2 - 4ac
            x = (-b (+-) sqrt (D)) / 2a            
            ==================================*/

            if (n < 0)
            {
                double D = (int)Math.Pow(a1, 2) - 4 * (-sumN * 2 / D_STEP);
                int x1 = (int)Math.Ceiling((-1 + Math.Sqrt(D)) / 2);
                int x2 = (int)Math.Ceiling((-1 - Math.Sqrt(D)) / 2);
                n = x1 > 0 ? x1 : x2;
            }
            return n;
        }

        //returns last number in the row by radius
        private int FindLastInRow(int radius)
        {
            int retNum = 1;            

            for (int ind=1; ind <= radius; ind ++)
            {
                retNum += (int)BASE_SIX * ind;               
            }     
            return retNum;
        }
   
        //Returns current object with coordinates filled
        private CellData GetCoordinates(int findNumber)
        {
            Row = new RowData();

            if (findNumber > 1)
            {                
                //find current row number(radius)
                Row.Radius = FindRadius(findNumber);
                //find last number in current row
                Row.LastNumber = FindLastInRow(Row.Radius);
                //set default first number in current row
                Row.FirstNumber = 2;

                //last number in previous row
                if (Row.Radius > 1 && Row.LastNumber != findNumber)
                {
                    Row.FirstNumber = FindLastInRow(Row.Radius - 1);
                    Row.FirstNumber++;
                }

                if (Row.LastNumber != findNumber && Row.FirstNumber != findNumber)
                {
                    //find current share index and the number on the second axis of the share
                    Row.SetOnAxisIndex(findNumber);
                }
                Row.SetCellData(findNumber);
            }
            return Row.Cell;
        }
        #endregion
    }
}