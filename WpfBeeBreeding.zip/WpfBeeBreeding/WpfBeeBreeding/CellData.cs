﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfBeeBreeding
{
    //x increasing to the right, 
    //y increasing to the upper left, 
    //z increasing to the lower left.
    class CellData
    {  
        public int X { get; set; }
        public int Y { get; set; }
        public int Z { get; set; }
        
        //constructor with default values
        public CellData()
        {
            X = 0; Y = 0; Z = 0;
        }        
    }  
}
