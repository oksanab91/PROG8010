﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfBeeBreeding
{
    class RowData
    {
        //last number in the row
        public int LastNumber { get; set; }
        //first number in the row
        public int FirstNumber { get; set; }
        //number on exis by share in the row
        public int OnAxisIndex { get; set; }
        //current share in the row
        public int Share { get; set; }
        public CellData Cell { get; set; }
        //current row
        public int Radius { get; set; }

        //constructor - set defaults
        public RowData()
        {
            Cell=new CellData();
            LastNumber = 0;
            FirstNumber = 0;
            OnAxisIndex = 0;
            Share = 0;
            Radius = 0;
        }

        //fill the coordinates of the current Cell object
        public void SetCellData(int findNumber)
        {
            int r = Radius;
            int onAx = 0;

            //define the flag(enum EAx) to fill coordinates 
            EAx setAx = EAx.AX_Y;
            if (Share == 3 || Share == 6)
                setAx = EAx.AX_X;
            else if (Share == 2 || Share == 5)
                setAx = EAx.AX_Z;

            //--------------------------------
            //set the coordinates of the Cell
            //--------------------------------
            //the number is the first in the circle
            if (FirstNumber == findNumber)
            {                
                onAx = 1;              
            }
            //the number is the last in the circle
            else if (LastNumber == findNumber)
            {                  
                onAx = 0;               
            }
            //--------------------------------
            if (LastNumber == findNumber || FirstNumber == findNumber)
            {
                Cell.Y = -r;
                Cell.Z = onAx;
                Cell.X = -Cell.Y - Cell.Z;
                setAx = EAx.AX_NONE;
            }
            else if (Share % 2 == 0)
            {
                onAx = findNumber - OnAxisIndex;
            }
            else
            {
                onAx = OnAxisIndex - findNumber;
                r = -r;
            }
            //--------------------------------
            switch (setAx)
            {  
                case EAx.AX_X:
                    Cell.X = r;
                    Cell.Z = onAx;
                    Cell.Y = -Cell.Z - Cell.X;
                    break;
                case EAx.AX_Y: 
                    Cell.Y = r;            
                    Cell.X = onAx;
                    Cell.Z = -Cell.Y - Cell.X;
                    break;
                case EAx.AX_Z:
                    Cell.Z = r;
                    Cell.Y = onAx;
                    Cell.X = -Cell.Y - Cell.Z;
                    break;
                default:
                    break;
            }            
        }

        //find current share index and the number on the second axis of the share
        public void SetOnAxisIndex(int findNumber) 
        {
            //there are 6 shares
            int[] shareArr = { 1, 2, 3, 4, 5, 6 };
            int ind = 0;
            int shareInd = 0;
            int foundInd = 0;

            while (foundInd == 0 && ind < shareArr.Length )
            {
                shareInd = shareArr[ind];
                //find the number on the second axis of the share
                foundInd = findOnAxisIndex(findNumber, shareInd);
                ind++;
            }
            OnAxisIndex = foundInd;
            Share = shareInd;
        }

        //find the number on the second axis of the share
        private int findOnAxisIndex(int findNumber, int shareInd)
        {
            int retNumber = 0;
            //use last number of the previous row
            int prevRowLastNum = FirstNumber - 1;
        
            if ((double)(findNumber - prevRowLastNum) / (LastNumber - prevRowLastNum) <= (double)shareInd / 6)
                retNumber = prevRowLastNum + (LastNumber - prevRowLastNum) * shareInd / 6;

            return retNumber;
        }
    }
}