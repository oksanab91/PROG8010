﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace WpfBeeBreeding
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DistancePreview dv; 
        public MainWindow()
        {
            InitializeComponent();
            dv = new DistancePreview();
            DataContext = dv;            
        }

        //loads file and displays the distances between the numbers
        private void btGetDistance_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "All Files (*.*)|*.*";

            bool? b = openFile.ShowDialog(this);
            if (b == true)
            {
                string filePath = openFile.FileName;
                if (filePath != string.Empty)
                {          
                    dv.ProcessFile(filePath);
                }
            }         
        }       
    }
}