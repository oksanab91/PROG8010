﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WpfBeeBreeding
{
    class DistancePreview: INotifyPropertyChanged
    {
        const string STOP_AT = "0 0";

        ObservableCollection<Distance> distances;
        public ObservableCollection<Distance> Distances 
            {
                get { return distances; }
                set { distances = value; OnChanged(); }
            }        

        # region test
        public void CreateFile()
        {
            Random r = new Random(1);
            const int rowNum = 50;
            string path = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string fullPath = Path.Combine(path, "Distance");
            
            if (!Directory.Exists(fullPath))
            {
                Directory.CreateDirectory(fullPath);  
            }

            //create the file            
            for (int row = rowNum; row > 0; row--)
            {                
                string rowText = Environment.NewLine + r.Next(1, rowNum) + " " + r.Next(1, rowNum);
                File.AppendAllText(Path.Combine(fullPath, "Distance.txt"), rowText);       
            }
            File.AppendAllText(Path.Combine(fullPath, "Distance.txt"), Environment.NewLine + STOP_AT);
        }
        #endregion

        #region find distances
        //Read the data from the file and find distances
        public void ProcessFile(string filePath = "")
        {         
            List<string> rows = new List<string>();
            Distances = new ObservableCollection<Distance>();
           
            //read the file
            if (File.Exists(filePath))
            {
                rows = File.ReadAllLines(filePath).ToList();
            }
            //-----------------------------------
            //find distances 
            int ind = 0;
            char delimiter = ' ';
            bool stopRead = false;
            if (rows.Count>0)
                stopRead = rows[ind].Contains(STOP_AT);

            while (ind < rows.Count && !stopRead)
            {
                string row = rows[ind];
                string[] numbers = row.Split(delimiter);

                int startNum = 0;
                int endNum = 0;
                if (numbers.Length > 1)
                {
                    //get numbers
                    int.TryParse(numbers[0], out startNum);
                    int.TryParse(numbers[1], out endNum);

                    //get the distance per pair 
                    if (startNum * endNum != 0)
                    {
                        Distance dis = new Distance() { StartNumber = startNum, EndNumber = endNum };
                        dis.GetDistance();
                        Distances.Add(dis);
                    }
                    stopRead = (startNum == 0 && endNum == 0);
                }
                ind++;
            }          
            //-----------------------------------
        }
        #endregion

        #region OnChange
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnChanged([CallerMemberName]string caller = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(caller));                
            }
        }
        #endregion
    }
}